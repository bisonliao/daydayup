#ifndef _MEM_H_INCLUDED_
#define _MEM_H_INCLUDED_

#include <map>
#include <string>
using namespace std;
#include "var.h"

class CMem
{
private:
	map<string, CVar> m_map;
public:
	void SetVar(const string &varname,
				CVar & var);
	void GetVar(const string &varname,
				CVar & var);
};

#endif
