#include "mem.h"

void CMem::SetVar(const string &varname, CVar&var)
{
	map<string,CVar>::iterator it = m_map.find(varname);
	if (it == m_map.end())
	{
		m_map.insert(std::pair<string, CVar>(varname, var));
	}
	else
	{
		it->second = var;
	}
}
void CMem::GetVar(const string &varname, CVar&var)
{
	map<string,CVar>::iterator it = m_map.find(varname);
	if (it == m_map.end())
	{
		CVar newvar;
		m_map.insert(std::pair<string, CVar>(varname, newvar));
		var = newvar;
	}
	else
	{
		var = it->second;
	}

}
