#if !defined(__XMLLEX2_H_INCLUDED__)
#define __XMLLEX2_H_INCLUDED__

#include "AnsiString.h"
#include "xmllex.h"


#endif
