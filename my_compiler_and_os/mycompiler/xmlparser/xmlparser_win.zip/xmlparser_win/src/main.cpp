#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xml.h"

#if !defined(_MAKE_DLL_)
int main(int argc, char** argv)
{
	if (argc < 3)
	{
		return 0;
	}
	Xml xxx;
	char errmsg[100];
	char buffer[1024];
	if (strcmp(argv[2], "FILE") == 0)
	{
		if (xxx.ReadFrmFile(argv[1], errmsg, sizeof(errmsg)) != 0)
		{
			printf("ERROR:[%s]\n", errmsg);
			return -1;
		}
	}
	else
	{
		if (xxx.ReadFrmBuffer(argv[1], strlen(argv[1]), 
									errmsg, sizeof(errmsg)) != 0)
		{
			printf("ERROR:[%s]\n", errmsg);
			return -1;
		}
	}

	memset(buffer, 0, sizeof(buffer));
	xxx.WriteToBuffer(buffer, sizeof(buffer));
	printf("%s\n", buffer);

	char value[100], prop[100];
	memset(value, 0, sizeof(value));
	memset(prop, 0, sizeof(prop));
	xxx.GetNodeInfo("/Data/AMT", value, sizeof(value), prop, sizeof(prop));
	printf("AMT=[%s]\n", value);
	return 0;
}
#endif
