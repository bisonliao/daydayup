#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "token.h"
#include <io.h>
#include <fstream>
#include <vector>
using namespace std;

#define yyFlexLexer l1FlexLexer
#include "lex1/FlexLexer.h"


int yylex(YYLVAL & yylval);
int WordAnalyze(vector<CToken> & words, const char * filename);
int parse(const vector<CToken> & words);
int ExpressionAnalyze(const vector<CToken> & words, unsigned int start);

typedef int (*FUNC)(char *varname, int varnamelen, 
					char * varvalue, int varvaluelen);

int lily(const char *buf, int buflen, FUNC f)
{
#define TMP_FILE1 "c:\\tmp1"	
#define TMP_FILE2 "c:\\tmp2"	
		

	ofstream of(TMP_FILE1);
	l1FlexLexer lex(NULL, &of);
	lex.__InitReadFrmBuffer(buf, buflen);
	lex.yylex();

	of.close();
	////////////////////////////////////
	
	vector<CToken> words;
	words.reserve(1024);
	int rc;
	//�ʷ�����
	rc = WordAnalyze(words, TMP_FILE1);
	if (rc < 0)
	{
		return  -(__LINE__);
	}
	if (rc == 0)
	{
		return -(__LINE__);
	}
	if (parse(words) != 0)
	{
		fprintf(stderr, "�﷨����ʧ��!\n");
		return -1;
	}
	return 0;
}


int main(int argc, char ** argv)
{
	if (argc != 2)
	{
		fprintf(stderr, "usage: %s source_file\n", argv[0]);
		return -1;
	}
	FILE * fp = fopen(argv[1], "rb");
	if (fp == NULL)
	{
		fprintf(stderr, "fopen(%s)ʧ��!\n", argv[1]);
		return -1;
	}
	string content;
	while (1)
	{
		char buf[1024];
		memset(buf, 0, sizeof(buf));
		int len;
		if ( (len = fread(buf, 1, sizeof(buf), fp)) <= 0)
		{
			break;
		}
		content += string(buf, len);
	}
	fclose(fp);
	fp = NULL;
	lily(content.c_str(), content.length(), NULL);
	return 0;
}

/*
*���ļ�filename���дʷ�������ʧ�ܷ��أ�1������Ҳ����ֱ���˳�����
*�ɹ����ط�����õĵ��ʵĸ���
*/
int WordAnalyze(vector<CToken> & words, const char * filename)
{
	int retcode;
	extern FILE * yyin;
	if ( (yyin = fopen(filename, "rb")) == NULL)
	{
		fprintf(stderr, "���ļ�[%s]ʧ��!\n", filename);
		return -1;
	}
	YYLVAL yylval;
	for (;;)
	{
		retcode = yylex(yylval);
		if (retcode == 0)
		{
			break;
		}
		CToken ttt(retcode, yylval);
		words.push_back(ttt);
	}
	fclose(yyin);
	return words.size();
}
